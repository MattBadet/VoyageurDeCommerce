﻿using System.Collections.Generic;

namespace PathfindingPCL
{
    public class BreadthFirst : Algorithm
    {
        public BreadthFirst(Graph _graph, GUI _ihm) : base(_graph, _ihm) {}

        private List<Node> notVisitedNodes;
        private Queue<Node> nodesToVisit;

        protected override void Run()
        {
            CreateListAndQueue();

            Node exitNode = graph.ExitNode();
            bool exitReached = false;
            while (nodesToVisit.Count != 0 && !exitReached)
            {
                Node currentNode = nodesToVisit.Dequeue();
                if (currentNode.Equals(exitNode))
                {
                    exitReached = true;
                }
                else
                {
                    AddNeighborsToQueue(currentNode);
                }
            }
        }

        private void AddNeighborsToQueue(Node currentNode)
        {
            foreach (Node node in graph.NodesList(currentNode))
            {
                if (notVisitedNodes.Contains(node))
                {
                    notVisitedNodes.Remove(node);
                    node.Precursor = currentNode;
                    node.DistanceFromBeginning = currentNode.DistanceFromBeginning + graph.CostBetweenNodes(currentNode, node);
                    nodesToVisit.Enqueue(node);
                }
            }
        }

        private void CreateListAndQueue()
        {
            notVisitedNodes = graph.NodesList();
            nodesToVisit = new Queue<Node>();
            nodesToVisit.Enqueue(graph.BeginningNode());
            notVisitedNodes.Remove(graph.BeginningNode());
        }
    }
}
