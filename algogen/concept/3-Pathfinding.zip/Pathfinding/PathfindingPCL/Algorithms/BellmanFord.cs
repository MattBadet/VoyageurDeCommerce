﻿using System;
using System.Collections.Generic;

namespace PathfindingPCL
{
    public class BellmanFord : Algorithm
    {
        public BellmanFord(Graph _graph, GUI _gui) : base(_graph, _gui) {}

        private bool distanceChanged = true;
        private List<Arc> arcsList;
        private int i;
        protected override void Run()
        {
            Initialisation();

            int nbLoopMax = graph.NodesCount() - 1;
            while (i < nbLoopMax && distanceChanged)
            {
                distanceChanged = false;
                ApplyEachArcAndUpdateDistance();
                i++;
            }
            
            ThrowExceptionIfNegativeDistance();
        }

        private void Initialisation()
        {
            distanceChanged = true;
            i = 0;
            arcsList = graph.ArcsList();
        }

        private void ApplyEachArcAndUpdateDistance()
        {
            foreach (Arc arc in arcsList)
            {
                if (arc.FromNode.DistanceFromBeginning + arc.Cost < arc.ToNode.DistanceFromBeginning)
                {
                    arc.ToNode.DistanceFromBeginning = arc.FromNode.DistanceFromBeginning + arc.Cost;
                    arc.ToNode.Precursor = arc.FromNode;
                    distanceChanged = true;
                }
            }
        }

        private void ThrowExceptionIfNegativeDistance()
        {
            foreach (Arc arc in arcsList)
            {
                if (arc.FromNode.DistanceFromBeginning + arc.Cost < arc.ToNode.DistanceFromBeginning)
                {
                    throw new Exception();
                }
            }
        }
    }
}
