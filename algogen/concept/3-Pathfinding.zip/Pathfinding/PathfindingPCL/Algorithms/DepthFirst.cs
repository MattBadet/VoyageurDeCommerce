﻿using System.Collections.Generic;

namespace PathfindingPCL
{
    public class DepthFirst : Algorithm
    {
        public DepthFirst(Graph _graph, GUI _gui) : base(_graph, _gui) {}

        private List<Node> notVisitedNodes;
        private Stack<Node> nodesToVisit;

        protected override void Run()
        {
            CreateListAndStack();

            Node exitNode = graph.ExitNode();
            bool exitReached = false;
            while (nodesToVisit.Count != 0 && !exitReached)
            {
                Node currentNode = nodesToVisit.Pop();
                if (currentNode.Equals(exitNode))
                {
                    exitReached = true;
                }
                else
                {
                    AddNeighborsToStack(currentNode);
                }
            }
        }

        private void AddNeighborsToStack(Node currentNode)
        {
            foreach (Node node in graph.NodesList(currentNode))
            {
                if (notVisitedNodes.Contains(node))
                {
                    notVisitedNodes.Remove(node);
                    node.Precursor = currentNode;
                    node.DistanceFromBeginning = currentNode.DistanceFromBeginning + graph.CostBetweenNodes(currentNode, node);
                    nodesToVisit.Push(node);
                }
            }
        }

        private void CreateListAndStack()
        {
            notVisitedNodes = graph.NodesList();
            nodesToVisit = new Stack<Node>();
            nodesToVisit.Push(graph.BeginningNode());
            notVisitedNodes.Remove(graph.BeginningNode());
        }
    }
}
