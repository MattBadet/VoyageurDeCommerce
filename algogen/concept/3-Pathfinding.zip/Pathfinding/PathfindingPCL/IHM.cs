﻿namespace PathfindingPCL
{
    public interface GUI
    {
        void PrintResult(string _path, double _distance);
    }
}
