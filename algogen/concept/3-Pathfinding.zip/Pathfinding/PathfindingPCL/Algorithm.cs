﻿namespace PathfindingPCL
{
    public abstract class Algorithm
    {
        protected Graph graph;
        protected GUI gui;

        public Algorithm(Graph _graph, GUI _gui)
        {
            graph = _graph;
            gui = _gui;
        }

        public void Solve()
        {
            graph.Clear();
            Run();
            gui.PrintResult(graph.ReconstructPath(), graph.ExitNode().DistanceFromBeginning);
        }

        protected abstract void Run();
    }
}
