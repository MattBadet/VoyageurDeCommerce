﻿using System;
using System.Collections.Generic;

namespace MetaheuristicsPCL
{
    public abstract class ParticleSwarmOptimizationAlgorithm : Algorithm
    {
        protected List<ISolution> currentSolutions;
        protected ISolution bestSoFarSolution;
        protected ISolution bestActualSolution;

        protected const int NB_INDIVIDUALS = 30;

        public override sealed void Solve(IProblem _pb, GUI _gui)
        {
            base.Solve(_pb, _gui);
            
            currentSolutions = new List<ISolution>();
            for (int i = 0; i < NB_INDIVIDUALS; i++)
            {
                ISolution newSolution = pb.RandomSolution();
                currentSolutions.Add(newSolution);
            }

            bestActualSolution = pb.BestSolution(currentSolutions);
            bestSoFarSolution = bestActualSolution;

            while (!Done())
            {
                UpdateGeneralVariables();
                UpdateSolutions();
                Increment();
            }
            SendResult();
        }

        protected abstract void UpdateSolutions();
        protected abstract void UpdateGeneralVariables();
        protected abstract bool Done();
        protected abstract void Increment();
    }
}
