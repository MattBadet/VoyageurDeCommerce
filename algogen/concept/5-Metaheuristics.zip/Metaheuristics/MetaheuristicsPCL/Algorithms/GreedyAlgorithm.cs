﻿
namespace MetaheuristicsPCL
{
    public abstract class GreedyAlgorithm : Algorithm
    {
        public override sealed void Solve(IProblem _pb, GUI _gui)
        {
            base.Solve(_pb, _gui);
            ConstructSolution();
            SendResult();
        }

        protected abstract void ConstructSolution();
    }
}
