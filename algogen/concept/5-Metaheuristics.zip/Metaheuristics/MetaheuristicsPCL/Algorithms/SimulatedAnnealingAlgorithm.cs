﻿using System.Collections.Generic;

namespace MetaheuristicsPCL
{
    public abstract class SimulatedAnnealingAlgorithm : Algorithm
    {
        protected ISolution currentSolution;
        protected ISolution bestSoFarSolution;
        protected double temperature;

        public override sealed void Solve(IProblem _pb, GUI _gui)
        {
            base.Solve(_pb, _gui);

            currentSolution = pb.RandomSolution();
            bestSoFarSolution = currentSolution;

            InitTemperature();
            while (!Done())
            {
                List<ISolution> Neighbours = pb.Neighbourhood(currentSolution);
                if (Neighbours != null)
                {
                    ISolution bestSolution = pb.BestSolution(Neighbours);
                    UpdateSolution(bestSolution);
                }
                Increment();
                UpdateTemperature();
            }
            SendResult();
        }

        protected abstract void UpdateTemperature();
        protected abstract void InitTemperature();
        protected abstract bool Done();
        protected abstract void UpdateSolution(ISolution _bestSolution);
        protected abstract void Increment();
    }
}
