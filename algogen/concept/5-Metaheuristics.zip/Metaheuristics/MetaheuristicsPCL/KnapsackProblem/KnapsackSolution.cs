﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MetaheuristicsPCL
{
    public class KnapsackSolution : ISolution
    {
        List<Box> loadedContent;
        public List<Box> LoadedContent
        {
            get { return loadedContent; }
            set { loadedContent = value; }
        }

        public double Weight
        {
            get { return LoadedContent.Sum(x => x.Weight); }
        }

        public double Value
        {
            get { return LoadedContent.Sum(x => x.Value); }
        }

        public KnapsackSolution()
        {
            loadedContent = new List<Box>();
        }

        public KnapsackSolution(KnapsackSolution _solution)
        {
            loadedContent = new List<Box>();
            loadedContent.AddRange(_solution.loadedContent);
        }

        public override string ToString()
        {
            String res = "Value : " + Value + " - Weight : " + Weight + "\n";
            res += "Loaded : ";
            res += String.Join(" - ", loadedContent);
            return res;
        }

        public override bool Equals(object _object)
        {
            KnapsackSolution solution = (KnapsackSolution)_object;
            if (solution.loadedContent.Count != loadedContent.Count || solution.Value != Value || solution.Weight != Weight)
            {
                return false;
            }
            else
            {
                foreach (Box box in loadedContent) {
                    if (!solution.loadedContent.Contains(box))
                    {
                        return false;
                    }
                }

            }
            return true;
        }

        public override int GetHashCode()
        {
            return (int) (Value * Weight);
        }
    }
}
