﻿using System.Collections.Generic;
using System.Linq;

namespace MetaheuristicsPCL
{
public class ParticleSwarmOptimizationForKnapsack : ParticleSwarmOptimizationAlgorithm
{
    int nbIterations = 1;
    private const int MAX_ITERATIONS = 200;

    protected override void UpdateSolutions()
    {
        List<Box> possibleBoxes = ((KnapsackProblem)pb).Boxes();

        foreach (ISolution genericSolution in currentSolutions)
        {
            KnapsackSolution solution = (KnapsackSolution)genericSolution;

            if (!solution.Equals(bestSoFarSolution))
            {
                AddElementFromBestActualSolution(solution);
                AddElementFromBestSoFarSolution(solution);

                while (solution.Weight > ((KnapsackProblem)pb).MaxWeight)
                {
                    RemoveElement(solution);
                }

                AddElementsUntilMaxWeight(possibleBoxes, solution);
            }
        }
    }

    private void AddElementsUntilMaxWeight(List<Box> possibleBoxes, KnapsackSolution solution)
    {
        double enableSpace = ((KnapsackProblem)pb).MaxWeight - solution.Weight;
        List<Box> availableBoxes = possibleBoxes.Except(solution.LoadedContent).Where(x => (x.Weight <= enableSpace)).ToList();

        while (enableSpace > 0 && availableBoxes.Count != 0)
        {
            int index = KnapsackProblem.randomGenerator.Next(0, availableBoxes.Count);
            solution.LoadedContent.Add(availableBoxes.ElementAt(index));
            enableSpace = ((KnapsackProblem)pb).MaxWeight - solution.Weight;
            availableBoxes = possibleBoxes.Except(solution.LoadedContent).Where(x => (x.Weight <= enableSpace)).ToList();
        }
    }

    private static void RemoveElement(KnapsackSolution solution)
    {
        int index = KnapsackProblem.randomGenerator.Next(0, solution.LoadedContent.Count);
        solution.LoadedContent.RemoveAt(index);
    }

    private void AddElementFromBestSoFarSolution(KnapsackSolution solution)
    {
        int index = KnapsackProblem.randomGenerator.Next(0, ((KnapsackSolution)bestSoFarSolution).LoadedContent.Count);
        Box element = ((KnapsackSolution)bestSoFarSolution).LoadedContent.ElementAt(index);
        if (!solution.LoadedContent.Contains(element))
        {
            solution.LoadedContent.Add(element);
        }
    }

    private void AddElementFromBestActualSolution(KnapsackSolution solution)
    {
        int index = KnapsackProblem.randomGenerator.Next(0, ((KnapsackSolution)bestActualSolution).LoadedContent.Count);
        Box element = ((KnapsackSolution)bestActualSolution).LoadedContent.ElementAt(index);
        if (!solution.LoadedContent.Contains(element))
        {
            solution.LoadedContent.Add(element);
        }
    }

    protected override void UpdateGeneralVariables()
    {
        bestActualSolution = currentSolutions.OrderByDescending(x => x.Value).FirstOrDefault();
        if (bestActualSolution.Value > bestSoFarSolution.Value)
        {
            bestSoFarSolution = bestActualSolution;
        }
    }

    protected override bool Done()
    {
        return nbIterations >= MAX_ITERATIONS;
    }

    protected override void Increment()
    {
        nbIterations++;
    }

    protected override void SendResult()
    {
        gui.PrintMessage(bestSoFarSolution.ToString());
    }
}
}
