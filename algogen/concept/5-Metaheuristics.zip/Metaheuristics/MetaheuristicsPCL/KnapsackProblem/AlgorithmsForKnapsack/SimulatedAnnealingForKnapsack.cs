﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MetaheuristicsPCL
{
    public class SimulatedAnnealingForKnapsack : SimulatedAnnealingAlgorithm
    {
        int nbIterationsWithoutUpdate = 1;
        int nbIterations = 1;
        private const int MAX_ITERATIONS_WITHOUT_UPDATE = 30;
        private const int MAX_ITERATIONS = 100;
		
        protected override void UpdateTemperature()
        {
            temperature *= 0.9;
        }

        protected override void InitTemperature()
        {
            temperature = 5;
        }

        protected override bool Done()
        {
            return nbIterationsWithoutUpdate >= MAX_ITERATIONS_WITHOUT_UPDATE && nbIterations >= MAX_ITERATIONS;
        }

        protected override void UpdateSolution(ISolution _bestSolution)
        {
            double seuil = 0.0;
            if (_bestSolution.Value < currentSolution.Value)
            {
                seuil = Math.Exp(-1 * (currentSolution.Value - _bestSolution.Value) / currentSolution.Value / temperature);
            }
            if (_bestSolution.Value > currentSolution.Value || KnapsackProblem.randomGenerator.NextDouble() < seuil)
            {
                currentSolution = _bestSolution;
                if (_bestSolution.Value > bestSoFarSolution.Value)
                {
                    bestSoFarSolution = _bestSolution;
                    nbIterationsWithoutUpdate = 0;
                }
            }
        }

        protected override void Increment()
        {
            nbIterationsWithoutUpdate++;
            nbIterations++;
        }

        protected override void SendResult()
        {
            gui.PrintMessage(bestSoFarSolution.ToString());
        }
    }
}
