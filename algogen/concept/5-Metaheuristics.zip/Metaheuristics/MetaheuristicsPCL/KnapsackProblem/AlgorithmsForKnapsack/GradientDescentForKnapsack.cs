﻿
namespace MetaheuristicsPCL
{
    public class GradientDescentForKnapsack : GradientDescentAlgorithm
    {
        int nbIterationsWithoutUpdate = 0;
        private const int MAX_ITERATIONS_WITHOUT_UPDATE = 50;

        protected override bool Done()
        {
            return nbIterationsWithoutUpdate >= MAX_ITERATIONS_WITHOUT_UPDATE;
        }

        protected override void Increment()
        {
            nbIterationsWithoutUpdate++;
        }

        protected override void UpdateSolution(ISolution _bestSolution)
        {
            if (_bestSolution.Value > currentSolution.Value)
            {
                currentSolution = _bestSolution;
                nbIterationsWithoutUpdate = 0;
            }
        }

        protected override void SendResult()
        {
            gui.PrintMessage(currentSolution.ToString());
        }
    }
}
