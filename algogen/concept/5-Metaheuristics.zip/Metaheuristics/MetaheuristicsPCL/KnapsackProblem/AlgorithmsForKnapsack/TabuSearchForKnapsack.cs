﻿using System.Collections.Generic;
using System.Linq;

namespace MetaheuristicsPCL
{
    public class TabuSearchForKnapsack : TabuSearchAlgorithm
    {
        int nbIterationsWithoutUpdate = 1;
        int nbIterations = 1;
        private const int MAX_ITERATIONS_WITHOUT_UPDATE = 30;
        private const int MAX_ITERATIONS = 100;
        private const int TABU_SEARCH_MAX_SIZE = 50;

        List<KnapsackSolution> tabuSolutions = new List<KnapsackSolution>();

        protected override bool Done()
        {
            return nbIterationsWithoutUpdate >= MAX_ITERATIONS_WITHOUT_UPDATE && nbIterations >= MAX_ITERATIONS;
        }

        protected override void UpdateSolution(ISolution _bestSolution)
        {
            if (!tabuSolutions.Contains((KnapsackSolution)_bestSolution))               
            {
                currentSolution = _bestSolution;
                AddToTabuList((KnapsackSolution)_bestSolution);
                if (_bestSolution.Value > bestSoFarSolution.Value)
                {
                    bestSoFarSolution = _bestSolution;
                    nbIterationsWithoutUpdate = 0;
                }
            }
        }

        protected override void Increment()
        {
            nbIterationsWithoutUpdate++;
            nbIterations++;
        }

        protected override void SendResult()
        {
            gui.PrintMessage(bestSoFarSolution.ToString());
        }

        protected override void AddToTabuList(ISolution _solution)
        {
            while (tabuSolutions.Count >= TABU_SEARCH_MAX_SIZE)
            {
                tabuSolutions.RemoveAt(0);
            }
            tabuSolutions.Add((KnapsackSolution)_solution);
        }

        protected override List<ISolution> RemoveSolutionsInTabuList(List<ISolution> Neighbours)
        {
            return Neighbours.Except(tabuSolutions).ToList();
        }
    }
}
