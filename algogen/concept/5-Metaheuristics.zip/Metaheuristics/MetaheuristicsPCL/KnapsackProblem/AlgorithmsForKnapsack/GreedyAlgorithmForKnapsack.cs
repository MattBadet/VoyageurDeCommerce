﻿using System.Collections.Generic;
using System.Linq;

namespace MetaheuristicsPCL
{
    public class GreedyAlgorithmForKnapsack : GreedyAlgorithm
    {
        KnapsackSolution solution;

        protected override void ConstructSolution()
        {
            KnapsackProblem problem = (KnapsackProblem) pb;
            List<Box> boxes = problem.Boxes();

            solution = new KnapsackSolution();

            foreach(Box currentBox in boxes.OrderByDescending(x => x.Value / x.Weight))
            {
                double spaceLeft = problem.MaxWeight - solution.Weight;
                if (currentBox.Weight < spaceLeft)
                {
                    solution.LoadedContent.Add(currentBox);
                }
            }
        }

        protected override void SendResult()
        {
            gui.PrintMessage(solution.ToString());
        }
    }
}
