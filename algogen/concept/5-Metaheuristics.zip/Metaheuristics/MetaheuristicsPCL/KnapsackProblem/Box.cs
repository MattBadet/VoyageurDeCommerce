﻿using System;

namespace MetaheuristicsPCL
{
    public class Box
    {
        public double Weight { get; set; }
        public double Value { get; set; }

        String Name { get; set; }

        public Box(String _name, double _weight, double _value)
        {
            Name = _name;
            Weight = _weight;
            Value = _value;
        }

        public override string ToString()
        {
            return Name + " (" + Weight + ", " + Value + ")";
        }
    }
}
