﻿namespace MetaheuristicsPCL
{
    public interface ISolution
    {
        double Value { get; }
    }
}
