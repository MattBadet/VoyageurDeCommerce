﻿
namespace MetaheuristicsPCL
{
    public abstract class Algorithm
    {
        protected IProblem pb;
        protected GUI gui;
        public virtual void Solve(IProblem _pb, GUI _gui)
        {
            pb = _pb;
            gui = _gui;
        }

        protected abstract void SendResult();
    }
}
