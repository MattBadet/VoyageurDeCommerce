﻿using System;

namespace MetaheuristicsPCL
{
    public interface GUI
    {
        void PrintMessage(String _message);
    }
}
