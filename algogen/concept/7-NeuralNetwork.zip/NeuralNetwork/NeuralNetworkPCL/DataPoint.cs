﻿using System;

namespace NeuralNetworkPCL
{
    internal class DataPoint
    {
        double[] inputs;        
        internal double[] Inputs
        {
            get
            {
                return inputs;
            }
        }

        double[] outputs;
        internal double[] Outputs
        {
            get
            {
                return outputs;
            }
        }

        internal DataPoint(string _str, int _outputNb)
        {
            string[] content = _str.Split(new char[] { '\t' }, StringSplitOptions.RemoveEmptyEntries);

            inputs = new double[content.Length - _outputNb];
            for (int i = 0; i < inputs.Length; i++)
            {
                inputs[i] = Double.Parse(content[i]);
            }

            outputs = new double[_outputNb];
            for (int i = 0; i < _outputNb; i++)
            {
                outputs[i] = Double.Parse(content[content.Length - _outputNb + i]);
            }
        }
    }
}
