﻿using System;

namespace NeuralNetworkPCL
{
    public class NeuralSystem
    {
        DataCollection data;
        NeuralNetwork network;
        GUI gui;
        int iterationNbwithoutBetterResults = 0;
        bool regressionTask;

        // Configuration
        double learningRate = 0.3;
        double maxError = 0.005;
        int maxIterations = 10001;

        public NeuralSystem(int _nbInputs, int _nbHidden, int _nbOutputs, String[] _data, double _trainingRatio, GUI _gui, bool _regressionTask=true)
        {
            data = new DataCollection(_data, _nbOutputs, _trainingRatio);
            network = new NeuralNetwork(_nbInputs, _nbHidden, _nbOutputs);
            gui = _gui;
            regressionTask = _regressionTask;
        }

        public void LearningRate(double _rate)
        {
            learningRate = _rate;
        }

        public void MaximumError(double _error)
        {
            maxError = _error;
        }

        public void MaximumIterations(int _iterations)
        {
            maxIterations = _iterations;
        }

        private double totalGeneralisationError = Double.PositiveInfinity;
        private double oldGeneralisationError = Double.PositiveInfinity;
        private double totalError = Double.PositiveInfinity;
        private double oldError = Double.PositiveInfinity;
        public void Run()
        {
            int i = 0;

            while (i < maxIterations && totalError > maxError && iterationNbwithoutBetterResults < 5)
            {
                InitIteration();

                foreach (DataPoint point in data.Points())
                {
                    Evaluate(point);
                    network.AdjustWeights(point, learningRate);
                }

                ApplyModelOnGeneralisationDataset();
                UpdateIterationsWithoutBetterResults();

                gui.PrintMsg("Iteration n°" + i + " - Total error : " + totalError + " - Gener Error : " + totalGeneralisationError + " - Rate : " + learningRate + " - Mean : " + String.Format("{0:0.00}", Math.Sqrt(totalError / data.Points().Length), "%2"));
                i++;
            }
        }

        private void InitIteration()
        {
            oldError = totalError;
            totalError = 0;
            oldGeneralisationError = totalGeneralisationError;
            totalGeneralisationError = 0;
        }

        private void Evaluate(DataPoint point)
        {
            double[] outputs = network.Evaluate(point);
            for (int outNb = 0; outNb < outputs.Length; outNb++)
            {
            if (!regressionTask)
            {
                if (outputs[outNb] > 0.5)
                {
                    outputs[outNb] = 1;
                }
                else
                {
                    outputs[outNb] = 0;
                }
            }
                double error = point.Outputs[outNb] - outputs[outNb];
                totalError += (error * error);
            }
        }

        private void ApplyModelOnGeneralisationDataset()
        {
            foreach (DataPoint point in data.GeneralisationPoints())
            {
                double[] outputs = network.Evaluate(point);
                for (int outNb = 0; outNb < outputs.Length; outNb++)
                {
                    double error = point.Outputs[outNb] - outputs[outNb];
                    totalGeneralisationError += (error * error);
                }
            }
        }

        private void UpdateIterationsWithoutBetterResults()
        {
            if (totalGeneralisationError > oldGeneralisationError)
            {
                iterationNbwithoutBetterResults++;
            }
            else
            {
                iterationNbwithoutBetterResults = 0;
            }
        }
    }
}
