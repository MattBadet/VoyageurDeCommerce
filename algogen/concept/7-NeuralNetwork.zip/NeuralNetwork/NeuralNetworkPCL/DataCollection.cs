﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace NeuralNetworkPCL
{
    internal class DataCollection
    {
        DataPoint[] trainingPoints;
        DataPoint[] generalisationPoints;

        private List<DataPoint> points;
        private int nbLines;
        internal DataCollection(String [] _content, int _outputNb, double _trainingRatio)
        {
            ReadPoints(_content, _outputNb);
            CreateTrainingSet(_trainingRatio);
            CreateGeneralisationSet();
        }

        private int ReadPoints(string[] _content, int _outputNb)
        {
            nbLines = _content.Length;
            points = new List<DataPoint>();
            for (int i = 0; i < nbLines; i++)
            {
                points.Add(new DataPoint(_content[i], _outputNb));
            }

            return nbLines;
        }

        private void CreateTrainingSet(double _trainingRatio)
        {
            int nbTrainingPoints = (int)(_trainingRatio * nbLines);
            trainingPoints = new DataPoint[nbTrainingPoints];
            Random rand = new Random();
            for (int i = 0; i < nbTrainingPoints; i++)
            {
                int index = rand.Next(points.Count);
                trainingPoints[i] = points.ElementAt(index);
                points.RemoveAt(index);
            }
        }

        private void CreateGeneralisationSet()
        {
            generalisationPoints = points.ToArray();
        }

        internal DataPoint[] Points()
        {
            return trainingPoints;
        }

        internal DataPoint[] GeneralisationPoints()
        {
            return generalisationPoints;
        }
    }
}
