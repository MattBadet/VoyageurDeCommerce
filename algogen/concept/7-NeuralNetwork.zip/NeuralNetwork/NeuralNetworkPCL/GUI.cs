﻿using System;

namespace NeuralNetworkPCL
{
    public interface GUI
    {
        void PrintMsg(String _msg);
    }
}
