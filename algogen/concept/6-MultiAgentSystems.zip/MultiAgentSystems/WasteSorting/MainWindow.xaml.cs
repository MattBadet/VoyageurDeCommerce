﻿using MultiAgentSystemPCL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WasteSorting
{
    public partial class MainWindow : Window
    {
        WasteEnvironment environment;
        bool play = false;
        DispatcherTimer updateTimer;

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
            environmentCanvas.MouseDown += environmentCanvas_MouseDown;

            updateTimer = new DispatcherTimer();
            updateTimer.Tick += dispatcherTimer_Tick;
            updateTimer.Interval = new TimeSpan(0, 0, 0, 0, 10);
        }

        void MainWindow_Loaded(object _sender, RoutedEventArgs _e)
        {
            environment = new WasteEnvironment(50, 30, environmentCanvas.ActualWidth, environmentCanvas.ActualHeight, 3);
            environment.environmentUpdatedEvent += environment_environmentUpdatedEvent;
            environment.Update();
        }

        void environmentCanvas_MouseDown(object _sender, MouseButtonEventArgs _mouseEvent)
        {
            if (play)
            {
                updateTimer.Stop();
            }
            else
            {
                updateTimer.Start();
            }
            play = !play;
        }

        void environment_environmentUpdatedEvent(List<Waste> _wasteList, List<WasteAgent> _agentList)
        {
            int nbWaste = _wasteList.Count();
            int nbAgentsLoaded = _agentList.Where(x => x.isLoaded()).Count();
            environmentCanvas.Children.Clear();
            foreach (Waste waste in _wasteList)
            {
                DrawWaste(waste);
            }
            foreach (WasteAgent agent in _agentList)
            {
                DrawAgent(agent);
            }
            Console.Out.WriteLine(nbWaste + " - " + nbAgentsLoaded);
            if (nbWaste == 3 && nbAgentsLoaded == 0)
            {
                updateTimer.Stop();
            }
        }

        private void DrawAgent(WasteAgent _agent)
        {
            Rectangle rect = new Rectangle();
            rect.Width = 3;
            rect.Height = 3;
            rect.Margin = new Thickness(_agent.PosX - 1, _agent.PosY - 1, 0, 0);
            if (_agent.isLoaded())
            {
                rect.Stroke = Brushes.Gray;
                rect.Fill = Brushes.Gray;
            }
            else
            {
                rect.Stroke = Brushes.Black;
                rect.Fill = Brushes.Black;
            }
            environmentCanvas.Children.Add(rect);
        }

        private void DrawWaste(Waste _waste)
        {
            Rectangle rect = new Rectangle();
            rect.Width = 3;
            rect.Height = 3;
            rect.Margin = new Thickness(_waste.PosX - 1, _waste.PosY - 1, 0, 0);
            Brush strokeAndFill = Brushes.Transparent;
            switch (_waste.Type)
            {
                case 0:
                    strokeAndFill = Brushes.Red;
                    break;
                case 1:
                    strokeAndFill = Brushes.Blue;
                    break;
                case 2:
                    strokeAndFill = Brushes.ForestGreen;
                    break;
            }
            rect.Stroke = strokeAndFill;
            rect.Fill = strokeAndFill;
            environmentCanvas.Children.Add(rect);

            Ellipse zone = new Ellipse();
            zone.Width = 2 * _waste.Zone;
            zone.Height = 2 * _waste.Zone;
            zone.Margin = new Thickness(_waste.PosX - _waste.Zone, _waste.PosY - _waste.Zone, 0, 0);
            zone.Fill = strokeAndFill;
            zone.Opacity = 0.3;
            environmentCanvas.Children.Add(zone);
        }

        void dispatcherTimer_Tick(object _sender, EventArgs _e)
        {
            environment.Update();
        }
    }
}
