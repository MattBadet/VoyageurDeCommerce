﻿using MultiAgentSystemPCL;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Fish
{
    public partial class MainWindow : Window
    {
        Ocean myOcean;

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        void MainWindow_Loaded(object _sender, RoutedEventArgs _e)
        {
            oceanCanvas.MouseDown += oceanCanvas_MouseDown;

            myOcean = new Ocean(250, oceanCanvas.ActualWidth, oceanCanvas.ActualHeight);
            myOcean.oceanUpdatedEvent += myOcean_oceanUpdatedEvent;
            
            DispatcherTimer dispatcherTimer = new DispatcherTimer(); 
            dispatcherTimer.Tick += dispatcherTimer_Tick;
            dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 15);
            dispatcherTimer.Start();
        }

        void dispatcherTimer_Tick(object _sender, EventArgs _e)
        {
            myOcean.UpdateEnvironnement();
        }

        void myOcean_oceanUpdatedEvent(FishAgent[] _fish, List<BadZone> _obstacles)
        {
            oceanCanvas.Children.Clear();

            foreach (FishAgent fish in _fish)
            {
                DrawFish(fish);
            }

            foreach (BadZone obstacle in _obstacles)
            {
                DrawObstacle(obstacle);
            }
            oceanCanvas.UpdateLayout();
        }

        private void DrawObstacle(BadZone _obstacle)
        {
            Ellipse circle = new Ellipse();
            circle.Stroke = Brushes.Black;
            circle.Width = 2 * _obstacle.Radius;
            circle.Height = 2 * _obstacle.Radius;
            circle.Margin = new Thickness(_obstacle.PosX - _obstacle.Radius, _obstacle.PosY - _obstacle.Radius, 0, 0);
            oceanCanvas.Children.Add(circle);
        }

        private void DrawFish(FishAgent _fish)
        {
            Line body = new Line();
            body.Stroke = Brushes.Black;
            body.X1 = _fish.PosX;
            body.Y1 = _fish.PosY;
            body.X2 = _fish.PosX - 10 * _fish.SpeedX;
            body.Y2 = _fish.PosY - 10 * _fish.SpeedY;
            oceanCanvas.Children.Add(body);
        }

        void oceanCanvas_MouseDown(object _sender, MouseButtonEventArgs _mouseEvent)
        {
            myOcean.AddObstacle(_mouseEvent.GetPosition(oceanCanvas).X, _mouseEvent.GetPosition(oceanCanvas).Y, 10);
        }
    }
}
