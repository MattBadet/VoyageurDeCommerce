﻿using MultiAgentSystemPCL;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace GameOfLife
{
    public partial class MainWindow : Window
    {
        DispatcherTimer updateTimer;
        bool running = false;
        GoLGrid grid;

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
            gridCanvas.MouseDown += gridCanvas_MouseDown;
        }

        void gridCanvas_MouseDown(object _sender, MouseButtonEventArgs _mouseEvent)
        {
            if (_mouseEvent.LeftButton == MouseButtonState.Pressed)
            {
                grid.ChangeState((int)(_mouseEvent.GetPosition(gridCanvas).X / 3), (int)(_mouseEvent.GetPosition(gridCanvas).Y / 3));
                grid.Update(false);
            }
            else if (_mouseEvent.RightButton == MouseButtonState.Pressed)
            {
                if (running)
                {
                    updateTimer.Stop();
                }
                else
                {
                    updateTimer.Start();
                }
                running = !running;
            }

        }

        void MainWindow_Loaded(object _sender, RoutedEventArgs _e)
        {
            grid = new GoLGrid((int) gridCanvas.ActualWidth / 3, (int) gridCanvas.ActualHeight / 3, 0.1);
            grid.gridUpdatedEvent += grid_gridUpdatedEvent;

            updateTimer = new DispatcherTimer();
            updateTimer.Tick += updateTimer_Tick;
            updateTimer.Interval = new TimeSpan(0, 0, 0, 0, 500);
            
            updateTimer.Start();
            running = true;
        }

        void grid_gridUpdatedEvent(bool[][] _grid)
        {
            gridCanvas.Children.Clear();

            for(int row = 0; row < _grid.Count(); row++) {
                for (int col = 0; col < _grid[0].Count(); col++)
                {
                    if (_grid[row][col])
                    {
                        DrawCell(row, col);
                    }
                }
            }
        }

        private void DrawCell(int _row, int _col)
        {
            Rectangle rect = new Rectangle();
            rect.Width = 3;
            rect.Height = 3;
            rect.Margin = new Thickness(3 * _row, 3 * _col, 0, 0);
            rect.Stroke = Brushes.Black;
            rect.Fill = Brushes.Black;

            gridCanvas.Children.Add(rect);
        }

        void updateTimer_Tick(object _sender, EventArgs _e)
        {
            grid.Update();
        }
    }
}
