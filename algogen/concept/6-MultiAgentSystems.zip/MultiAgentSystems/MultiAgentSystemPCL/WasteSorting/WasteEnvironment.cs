﻿using System;
using System.Collections.Generic;

namespace MultiAgentSystemPCL
{
    public delegate void EnvironmentUpdated(List<Waste> _waste, List<WasteAgent> _agents);

    public class WasteEnvironment
    {
        List<Waste> wasteList;
        List<WasteAgent> agents;
        public Random randomGenerator;
        double MAX_WIDTH;
        double MAX_HEIGHT;
        protected int nbIterations = 0;

        public event EnvironmentUpdated environmentUpdatedEvent;

        public WasteEnvironment(int _nbWaste, int _nbAgents, double _width, double _height, int _nbWasteTypes)
        {
            if (randomGenerator == null)
            {
                randomGenerator = new Random();
            }
            MAX_WIDTH = _width;
            MAX_HEIGHT = _height;
            CreateWasteList(_nbWaste, _nbWasteTypes);
            CreateAgentsList(_nbAgents);
        }

        private void CreateAgentsList(int _nbAgents)
        {
            agents = new List<WasteAgent>();
            for (int i = 0; i < _nbAgents; i++)
            {
                WasteAgent agent = new WasteAgent(randomGenerator.NextDouble() * MAX_WIDTH, randomGenerator.NextDouble() * MAX_HEIGHT, this);
                agents.Add(agent);
            }
        }

        private void CreateWasteList(int _nbWaste, int _nbWasteTypes)
        {
            wasteList = new List<Waste>();
            for (int i = 0; i < _nbWaste; i++)
            {
                Waste waste = new Waste(randomGenerator.NextDouble() * MAX_WIDTH, randomGenerator.NextDouble() * MAX_HEIGHT, randomGenerator.Next(_nbWasteTypes));
                wasteList.Add(waste);
            }
        }

        internal void SetWaste(Waste _goal)
        {
            _goal.Increase();
        }

        internal Waste TakeWaste(Waste _goal)
        {
            if (_goal.Size == 1)
            {
                wasteList.Remove(_goal);
                return _goal;
            }
            else
            {
                _goal.Decrease();
                Waste load = new Waste(_goal);
                return load;
            }
        }

        public void Update()
        {
            foreach (WasteAgent agent in agents)
            {
                agent.UpdateDirection(wasteList);
                agent.UpdatePosition(MAX_WIDTH, MAX_HEIGHT);
            }

            nbIterations++;
            if (nbIterations % 500 == 0)
            {
                wasteList.Reverse();
            }

            if (environmentUpdatedEvent != null)
            {
                environmentUpdatedEvent(wasteList, agents);
            }
        }
    }
}
