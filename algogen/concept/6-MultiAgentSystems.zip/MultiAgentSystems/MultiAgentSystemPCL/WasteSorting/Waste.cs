﻿
namespace MultiAgentSystemPCL
{
    public class Waste : ObjectInWorld
    {
        private const double PROBA_DECREASE = 0.6;

        protected int type;
        public int Type
        {
            get { return type; }
        }

        protected int size = 1;
        public int Size
        {
            get { return size; }
        }

        public int Zone
        {
            get { return 10 + (8 * size - 1); }
        }

        public Waste(double _posX, double _posY, int _type)
        {
            PosX = _posX;
            PosY = _posY;
            type = _type;
        }

        public Waste(Waste _goal)
        {
            PosX = _goal.PosX;
            PosY = _goal.PosY;
            type = _goal.type;
        }

        internal void Decrease()
        {
            size--;
        }

        internal void Increase()
        {
            size++;
        }

        internal double ProbaToTake()
        {
            double proba = 1.0;
            for (int i = 1; i < size; i++)
            {
                proba *= PROBA_DECREASE;
            }
            return proba;
        }
    }
}
