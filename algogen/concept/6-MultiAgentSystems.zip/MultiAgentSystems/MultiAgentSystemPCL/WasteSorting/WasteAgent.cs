﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MultiAgentSystemPCL
{
    public class WasteAgent : ObjectInWorld
    {
        protected const double STEP = 3;
        protected const double CHANGE_DIRECTION_PROB = 0.05;

        protected Waste load = null;
        protected double speedX;
        protected double speedY;
        protected WasteEnvironment env;
        protected bool busy = false;


        public WasteAgent(double _posX, double _posY, WasteEnvironment _env)
        {
            PosX = _posX;
            PosY = _posY;
            env = _env;
            speedX = env.randomGenerator.NextDouble() - 0.5;
            speedY = env.randomGenerator.NextDouble() - 0.5;
            Normalize();
        }

        private void Normalize()
        {
            double length = Math.Sqrt(speedX * speedX + speedY * speedY);
            speedX = speedX / length;
            speedY = speedY / length;
        }

        public bool isLoaded()
        {
            return load != null;
        }

        public void UpdatePosition(double _maxWidth, double _maxHeight) {
            PosX += STEP * speedX;
            PosY += STEP * speedY;
            if (PosX < 0)
            {
                PosX = 0;
            }
            if (PosY < 0)
            {
                PosY = 0;
            }
            if (PosX > _maxWidth)
            {
                PosX = _maxWidth;
            }
            if (PosY > _maxHeight)
            {
                PosY = _maxHeight;
            }
        }

        internal void UpdateDirection(List<Waste> _wasteList)
        {
            Waste goal = ChooseGoal(_wasteList);
            if (goal == null || busy)
            {
                RandomMove(goal);
            }
            else
            {
                GoTo(goal);
                if (DistanceTo(goal) < STEP)
                {
                    TakeOrDeposit(goal);
                }
            }
            Normalize();
        }

        private Waste ChooseGoal(List<Waste> _wasteList)
        {
            List<Waste> inZone = _wasteList.Where(x => DistanceTo(x) < x.Zone).OrderBy(x => DistanceTo(x)).ToList();
            Waste goal;
            if (load == null)
            {
                goal = inZone.FirstOrDefault();
            }
            else
            {
                goal = inZone.Where(x => x.Type == load.Type).FirstOrDefault();
            }
            return goal;
        }

        private void RandomMove(Waste goal)
        {
            if (env.randomGenerator.NextDouble() < CHANGE_DIRECTION_PROB)
            {
                speedX = env.randomGenerator.NextDouble() - 0.5;
                speedY = env.randomGenerator.NextDouble() - 0.5;
            }
            if (busy && goal == null)
            {
                busy = false;
            }
        }

        private void GoTo(Waste goal)
        {
            speedX = goal.PosX - PosX;
            speedY = goal.PosY - PosY;
        }
        
        private void TakeOrDeposit(Waste goal)
        {
            if (load == null)
            {
                if (env.randomGenerator.NextDouble() < goal.ProbaToTake())
                {
                    load = env.TakeWaste(goal);
                }
            }
            else
            {
                env.SetWaste(goal);
                load = null;
            }
            busy = true;
        }
    }
}
