%*** R�gles ***

reines(N, Res) :-
    numlist(1,N,Base),
    permutation(Res,Base),
    diagsOK(Res).

diagsOK( [ _ | [] ] ) :-
    true.

diagsOK([Tete | Queue]) :-
     diagReine(Tete, Queue, 1),
     diagsOK(Queue).

diagReine(_, [], _) :-
     true.

diagReine(Reine, [T|Q], Col) :-
     (Reine + Col) =\= T,
     (Reine - Col) =\= T,
     diagReine(Reine, Q, Col+1).
