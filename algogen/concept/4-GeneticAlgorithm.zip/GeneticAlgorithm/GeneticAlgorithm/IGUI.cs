﻿namespace GeneticAlgorithm
{
    public interface IGUI
    {
        void PrintBestIndividual(Individual individual, int generation);
    }
}
