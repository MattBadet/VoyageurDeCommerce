﻿using System;

namespace GeneticAlgorithm
{
    internal interface IGene
    {
        void Mutate();
    }
}
