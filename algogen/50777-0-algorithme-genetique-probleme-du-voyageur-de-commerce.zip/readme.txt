Algorithme genetique probleme du voyageur de commerce-----------------------------------------------------
Url     : http://codes-sources.commentcamarche.net/source/50777-algorithme-genetique-probleme-du-voyageur-de-commerceAuteur  : roddehugoDate    : 06/01/2014
Licence :
=========

Ce document intitul� � Algorithme genetique probleme du voyageur de commerce � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Projet r&eacute;alis&eacute; dans le cadre d'un TPE de 1&egrave;re, ce programme
 permet de trouver une bonne solution via un algorithme g&eacute;n&eacute;tique.

<br />
<br />L'algorithme g&eacute;n&eacute;tique, est un moyen de trouver un
e solution satisfaisante dans un d&eacute;lai raisonnable. Ce n'est pas la solut
ion optimale qui elle mettrait des ann&eacute;es a &ecirc;tre calcul&eacute;es a
vec beaucoup d'individus en param&egrave;tre. C'est un algorithme inspir&eacute;
 de la biologie, de la reproduction, mutation, et adaptation des &ecirc;tres viv
ants &agrave; leur environement. 
<br />
<br />Ce programme n'est pas vraiment
 optimis&eacute;, le but n'&eacute;tait pas non plus d'arriver &agrave; un r&eac
ute;sultat parfait. Mais tout de m&ecirc;me, il fonctionne relativement bien. On
 peut constater une nette am&eacute;lioration de la longueur du chemin.
<br />V
ous pouvez sauvegarder les villes, pour pouvoir faire d'autres tests sur celles-
ci puisqu'elles sont cr&eacute;es al&eacute;atoirement. lors de l'initialisation
.
<br />
<br />Le code est relativement comment&eacute; et l&eacute;ger.
<br 
/><a name='mise-a-jour'></a><h2>Mise &agrave; jour</h2>
<br />Plus besoin de m
ettre le nombre de villes pour les r&eacute;utilisers.
<br />L&eacute;g&egrave;
re am&eacute;lioration du code.
<br /><a name='conclusion'></a><h2>Conclusion</
h2>
<br />Bonne lecture
